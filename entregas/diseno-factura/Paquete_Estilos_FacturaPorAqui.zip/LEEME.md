# Diseño de factura · FacturaPorAquí

Entrega para integrar en una rama de trabajo y revisar en pruebas. La referencia de código fue `Jen456/invoice15`, rama `plataforma`. Confirma el repositorio, la rama y el SHA desplegados en `app.facturaporaqui.com` antes de usar el parche como base.

## Experiencia del comercio

En **Configuración → Diseño de factura**, el propietario elige Clásico, Corporativo, Minimalista, Banda de marca o Compacto. Puede personalizar los colores principal y secundario, restaurar la paleta de la plantilla, ver una factura de muestra y guardar el diseño del comercio. El logo y el nombre comercial se resuelven desde el establecimiento cuando la configuración existente lo permite, con los datos de la empresa como respaldo. La vista previa HTML incluida en este paquete usa dos comercios ficticios y guarda sus preferencias de demostración en el navegador.

## Archivos para Claude

- `integracion/core/configuracion/templates/configuracion/diseno_factura.html` y `integracion/static/{css,js}/diseno_factura.*` contienen la pantalla y la actualización de la vista previa.
- `integracion/core/comprobantes/ride_styles.py` define los cinco estilos permitidos, los colores HEX y el contexto del PDF.
- `integracion/templates/ride/_variantes_factura.html` y `integracion/static/css/ride_variants.css` aplican los estilos al RIDE de factura.
- `integracion/RIDE-solo-presentacion.patch` modifica dos puntos de la plantilla A4 actual. Ejecuta `git apply --check` en la base confirmada y compara el contexto si la plantilla difiere.
- `muestras_pdf/` incluye un PDF de ejemplo por estilo, generado con el mismo contenido fiscal y datos ficticios.

## Integración en el repositorio de producción

1. Parte del commit desplegado en una rama independiente. Incorpora los archivos bajo sus rutas relativas. Comprueba que `skin.html` y sus bloques coincidan con la base. Agrega **Diseño de factura** después de **Facturación y numeración** en la navegación existente.
2. Crea las rutas de edición y vista previa en Configuración con los decoradores, la membresía del comercio y el control de rol propietario ya usados en el proyecto. Resuelve el comercio desde la sesión, nunca desde un identificador enviado por el formulario. Aplica la misma autorización al guardar y al abrir la vista previa.
3. Persiste una configuración por comercio con una migración aditiva. Usa un valor ausente para comercios sin personalización y valida en el servidor el estilo y ambos colores al guardar. `normalize()` proporciona valores de respaldo para las lecturas. En POST, rechaza valores desconocidos o colores inválidos y presenta un error en el formulario. Conserva la ruta original cuando la función esté desactivada o el comercio carezca de diseño guardado.
4. Renderiza la pantalla con `styles` (objetos con `id`, `name`, `description`, `primary` y `secondary`), `current`, `preview_url` y `form_error` cuando corresponda. Usa la ruta nombrada `diseno_factura_preview` en la plantilla o ajusta su namespace al del proyecto. Para el GET de muestra, renderiza el RIDE con un comprobante ficticio en memoria y una marca visible de muestra. Lee y normaliza `style`, `primary` y `secondary`, y usa una respuesta privada sin caché. La vista previa y el guardado de diseño funcionan sin crear comprobantes.
5. En el flujo que crea `Sale.pdf_authorized`, conserva para cada factura nueva una copia del estilo, versión y colores efectivos. Mantén esa copia estable durante reintentos. Pasa `ride_style` a `Sale.ride_pdf()` desde la copia del comprobante mediante `template_context()`. Usa el diseño original en documentos históricos sin metadatos. `SalePrintA4View` debe servir el archivo autorizado guardado cuando exista. Si se necesita una regeneración, toma la versión y la paleta del comprobante y conserva el tratamiento actual de los históricos. Mantén las hojas CSS de otras clases de documentos separadas.
6. Prueba con un piloto por comercio y conserva un interruptor que permita ocultar la edición y volver al render predeterminado para facturas nuevas. Verifica que esto permita seguir sirviendo los PDF ya guardados y que la descarga normal y el adjunto usen el mismo PDF.

## Validación antes del piloto

- Prueba dos comercios con paletas distintas, usuarios sin permiso de edición y cambios de comercio en la misma sesión.
- Compara cada estilo contra el RIDE original y contra la ficha técnica vigente del SRI, en particular el Anexo 2. Verifica que todos los campos aplicables sean legibles, incluida la clave de acceso y su código de barras. La autorización corresponde al comprobante electrónico. Identifica estos estilos como plantillas de FacturaPorAquí.
- Comprueba que XML, firma, envío al SRI, impuestos y secuenciales sigan el flujo existente. Usa datos ficticios, sin emisiones reales ni correos a clientes. Comprueba con un archivo histórico que el PDF guardado se descarga con los mismos bytes.
- Revisa impresión A4, PDF de varias páginas, descripciones largas y combinaciones claras y oscuras. En la prueba local, cada diseño produjo un PDF A4 distinto con el mismo texto fiscal y se verificó un caso de 62 líneas de tres páginas.

Ficha técnica oficial del SRI  
https://www.sri.gob.ec/facturacion-electronica
